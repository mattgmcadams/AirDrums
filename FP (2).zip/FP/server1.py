# server1.py
from sense_hat import SenseHat
import socket
import json
import Gamepad
import time

# Gamepad settings
gamepadType = Gamepad.PS4
button1 = 'TRIANGLE'  # red drum
button2 = 'SQUARE'  # yellow drum
button3 = 'CROSS'  # blue drum
button4 = 'CIRCLE'  # green drum
buttonSelect = 'SHARE'  # select button
buttonPlay = 'R3'  # playstation button
buttonStart = 'OPTIONS'  # start button

# Game Variables
global drumState  # Used to rotate through drum pad assignments
global drumSet  # Used to set sound profile
drumState = 1
drumSet = 1

# Creating colors
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# SenseHat settings
sense = SenseHat()
sense.clear()

# Server settings
host = '131.128.51.135'
port = 9607  # change to other port if this one is occupied
s = socket.socket()
s.bind((host, port))
s.listen(10)


def giveData(buttonP):
    if buttonP == button1:
        data = {"red": 1}
        senData(data)
    elif buttonP == button2:
        data = {"yellow": 1}
        senData(data)
    elif buttonP == button3:
        data = {"blue": 1}
        senData(data)
    elif buttonP == button4:
        data = {"green": 1}
        senData(data)
    elif buttonP == buttonSelect:
        global drumState
        if drumState < 5:
            drumState += 1
        else:
            drumState = 1
        sense.show_message(f"L{drumState}", scroll_speed=0.03)
        data = {"select": drumState}
        senData(data)
    elif buttonP == buttonPlay:
        data = {"play": 1}
        senData(data)
    elif buttonP == buttonStart:
        global drumSet
        if drumSet == 1:
            drumSet = 2
        elif drumSet == 2:
            drumSet = 3
        else:
            drumSet = 1
        sense.show_message(f"M{drumSet}", scroll_speed=0.03)
        data = {"start": drumSet}
        senData(data)


def senData(data):
    msg = json.dumps(data)
    conn.sendall(msg.encode('ascii'))


while True:
    try:
        print("Trying to connect")
        conn, addr = s.accept()
        if conn:
            print("Connection established, from: %s" % str(addr))
            while not Gamepad.available():
                time.sleep(1)
            gamepad = gamepadType()
            print('Gamepad connected')
            # Handle joystick updates one at a time
            while gamepad.isConnected():
                eventType, control, value = gamepad.getNextEvent()
                if eventType == 'BUTTON':
                    # Button changed
                    if control == button1:
                        # red drum
                        if value:
                            sense.clear(RED)
                            print('|||| --  --  -- ')
                            giveData(control)
                    elif control == button2:
                        # yellow drum
                        if value:
                            sense.clear(YELLOW)
                            print(' -- |||| --  --')
                            giveData(control)
                    elif control == button3:
                        # blue drum
                        if value:
                            sense.clear(BLUE)
                            print(' --  -- |||| -- ')
                            giveData(control)
                    elif control == button4:
                        # green drum
                        if value:
                            sense.clear(GREEN)
                            print(' --  --  -- ||||')
                            giveData(control)
                    elif control == buttonSelect:
                        # select layout
                        if value:
                            sense.clear()
                            print('Select button pressed')
                            giveData(control)
                    elif control == buttonPlay:
                        # PlayStation button
                        if value:
                            sense.clear()
                            print("PlayStation button pressed")
                            giveData(control)
                    elif control == buttonStart:
                        # unused
                        if value:
                            sense.clear()
                            print("Start button pressed")
                            giveData(control)
                    else:
                        print(gamepad.getNextEvent())
        else:
            # if not connected
            time.sleep(1)
    except KeyboardInterrupt:
        break
