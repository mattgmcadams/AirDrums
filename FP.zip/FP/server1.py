# server1.py
from sense_hat import SenseHat
import socket
import json
import Gamepad
import time

# Gamepad settings
gamepadType = Gamepad.PS4
button1 = 'TRIANGLE'  # red drum
button2 = 'SQUARE'  # yellow drum
button3 = 'CROSS'  # blue drum
button4 = 'CIRCLE'  # green drum
buttonSelect = 'SHARE'  # select button
buttonPlay = 'R3'  # playstation button
buttonStart = 'OPTIONS'  # start button

# Game Variables
global drumState  # Used to rotate through drum pad assignments
drumState = 1

# Creating colors
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# SenseHat settings
sense = SenseHat()
sense.clear()

# Server settings
host = '192.168.43.219'
port = 9606  # change to other port if this one is occupied
s = socket.socket()
s.bind((host, port))
s.listen(10)


# Functions
def giveData(r, y, b, g, sel, play, start):
    global drumState
    if sel:
        if drumState < 5:
            drumState += 1
        else:
            drumState = 0
        sense.show_message(f"Layout {drumState}", scroll_speed=0.03)
    data = {"red": r, "yellow": y, "blue": b, "green": g, "select": drumState, "play": play, "start": start}
    # print("Data is: ", data)
    msg = json.dumps(data)
    conn.sendall(msg.encode('ascii'))


while True:
    try:
        print("Trying to connect")
        conn, addr = s.accept()
        if conn:
            print("Connection established, from: %s" % str(addr))
            while not Gamepad.available():
                time.sleep(1)
            gamepad = gamepadType()
            print('Gamepad connected')
            # Handle joystick updates one at a time
            while gamepad.isConnected():
                eventType, control, value = gamepad.getNextEvent()
                if not eventType:
                    # if no button pressed
                    giveData(0, 0, 0, 0, 0, 0, 0)
                # Determine the type
                if eventType == 'BUTTON':
                    # Button changed
                    if control == button1:
                        # red drum
                        if value:
                            sense.clear(RED)
                            print('|||| --  --  -- ')
                            giveData(1, 0, 0, 0, 0, 0, 0)
                    elif control == button2:
                        # yellow drum
                        if value:
                            sense.clear(YELLOW)
                            print(' -- |||| --  --')
                            giveData(0, 1, 0, 0, 0, 0, 0)
                    elif control == button3:
                        # blue drum
                        if value:
                            sense.clear(BLUE)
                            print(' --  -- |||| -- ')
                            giveData(0, 0, 1, 0, 0, 0, 0)
                    elif control == button4:
                        # green drum
                        if value:
                            sense.clear(GREEN)
                            print(' --  --  -- ||||')
                            giveData(0, 0, 0, 1, 0, 0, 0)
                    elif control == buttonSelect:
                        # select layout
                        if value:
                            sense.clear()
                            print('Select button pressed')
                            giveData(0, 0, 0, 0, 1, 0, 0)
                    elif control == buttonPlay:
                        # PlayStation button
                        if value:
                            sense.clear()
                            print("PlayStation button pressed")
                            giveData(0, 0, 0, 0, 0, 1, 0)
                    elif control == buttonStart:
                        # unused
                        if value:
                            sense.clear()
                            print("Start button pressed")
                            giveData(0, 0, 0, 0, 0, 0, 1)
                    else:
                        print(gamepad.getNextEvent())
        else:
            # if not connected
            time.sleep(1)
    except KeyboardInterrupt:
        conn.close()
        break
