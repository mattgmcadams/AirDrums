#!/usr/bin/env python
# coding: utf-8
# Load the gamepad and time libraries

# server1.py
from sense_hat import SenseHat
import socket
import json
import requests
import Gamepad
import time
from time import sleep

# Gamepad settings
gamepadType = Gamepad.PS4
button0 = 'CROSS'  # trig
button1 = 'CIRCLE'  # left
buttonExit = 'R3'
buttonStart = 'OPTIONS'  # right
button2 = 'TRIANGLE'  # down
button3 = 'SQUARE'  # up

# Server settings
# sense = SenseHat()
host = '192.168.1.166'
port = 9606  # change to other port if this one is occupied
s = socket.socket()
s.bind((host, port))
s.listen(10)


# Functions

def giveData(r, y, b, g):
    # message1
    data = {"red": r, "yellow": y, "blue": b, "green": g}
    print("Data is: ", data)
    msg = json.dumps(data)
    conn.sendall(msg.encode('ascii'))


def getData():
    # message2
    msg = conn.recv(1024)
    feedback = json.loads(msg.decode('ascii'))
    print("Feedback is: ", feedback)
    if "stop" in feedback:
        print("stopped")


while True:
    try:
        print("trying to connect")
        conn, addr = s.accept()
        if conn:
            print("Connection established, from: %s" % str(addr))
            # Wait for a connection
            if not Gamepad.available():
                print('Please connect your gamepad...')
                while not Gamepad.availabdle():
                    time.sleep(1)
            gamepad = gamepadType()
            print('Gamepad connected')
            # Handle joystick updates one at a time
            while gamepad.isConnected():
                eventType, control, value = gamepad.getNextEvent()
                # Determine the type
                if eventType == 'BUTTON':
                    # Button changed
                    if control == button0:
                        # blue drum
                        if value:
                            print(' --  -- |||| -- ')
                            giveData(0, 0, 1, 0)
                    elif control == button1:
                        # green drum
                        if value:
                            print(' --  --  -- ||||')
                            giveData(0, 0, 0, 1)
                    elif control == button3:
                        # yellow drum
                        if value:
                            print(' -- |||| --  --')
                            giveData(0, 1, 0, 0)
                    elif control == button2:
                        # red drum
                        if value:
                            print('|||| --  --  -- ')
                            giveData(1, 0, 0, 0)
                    else:
                        print(gamepad.getNextEvent())
        else:
            time.sleep(1)
    except KeyboardInterrupt:
        conn.close()
        break
