#!/usr/bin/env python
# coding: utf-8

# Load the gamepad and time libraries
import Gamepad
import time
from time import sleep

# Gamepad settings
gamepadType = Gamepad.PS4
button0 = 'CROSS' #trig
button1 = 'CIRCLE' #left
buttonExit = 'R3'
buttonStart = 'OPTIONS' #right
button2 = 'TRIANGLE' #down
button3 = 'SQUARE' #up
# Servo Settings 

#Functions to be done when button press ie drum smack

	
        
# Wait for a connection
if not Gamepad.available():
    print('Please connect your gamepad...')
    while not Gamepad.availabdle():
        time.sleep(1.0)
gamepad = gamepadType()
print('Gamepad connected')

# Set some initial state
#any values necessary to initialize ur program 

# Handle joystick updates one at a time
while gamepad.isConnected():
    # Wait for the next event
    eventType, control, value = gamepad.getNextEvent()

    # Determine the type
    if eventType == 'BUTTON':
        # Button changed
        if control == button0:
            # Trigger
            if value:
                print(' --  -- |||| -- ')

        elif control == button1:
            # Left
            if value:
                print(' --  --  -- ||||')

        elif control == buttonStart:
            # Right
            if value:
                print('Move Servo Right')
        
        elif control == button3:
            # Up
            if value:
                print(' -- |||| --  --')
        elif control == button2:
            # Down
            if value:
                print('|||| --  --  -- ')

                
        elif control == buttonExit:
            # Exit
            if value:
                break
        else:
            print(gamepad.getNextEvent())
